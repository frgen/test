#include <stdio.h>
#include <stdlib.h>
#include "UTN_INPUT.h"


int main()
{
    int edad;

    edad = pedirEntero("Edad: ");

    return 0;
}

