#include <stdio.h>
#include <stdlib.h>
#define T 5

void cargarVector(int[], int);
void ordenarVector(int[], int);

int main()
{
    int miVector[T]= {2,6,1,3,4};
    int i;
    int j;
    int aux;
    int flag=0;

    cargarVector(miVector, T);
    ordenarVector(miVector, T);

    for(i=0; i<T-1; i++)
    {
        for(j=i+1; j<T; j++)
        {
            if(miVector[i]>miVector[j])//Criterio de ordenamiento
            {
                aux = miVector[i];
                miVector[i] = miVector[j];
                miVector[j] = aux;
            }
        }
    }

    printf("Ingrese un numero: ");
    scanf("%d", &miVector[i]);

    for(i=0; i<T; i++)
    {
        if(aux==miVector[i])
        {
            flag=1;
            printf("Posicion %d\n", i);
            break;
        }

        printf("%d\n", miVector[i]);
    }

    if(flag==0)
    {
        printf("No se encontro el dato\n");
    }

    return 0;
}

void cargarVector(int vector[], int tam)
{
    int i;

    for(i=0; i<tam; i++)
    {
        printf("Ingrese un numero: \n");
        scanf("%d", i);
    }

    return;
}
