#include <stdio.h>
#include <stdlib.h>

int sumar(int, int);

int main()
{
    int suma;
    int numeroUno;
    int numeroDos;

    printf("Ingrese el primer numero: ");
    scanf("%d", &numeroUno);

    printf("Ingrese el segundo numero: ");
    scanf("%d", &numeroDos);

    suma = sumar(numeroUno, numeroDos);

    printf("El resultado es: %d", suma);

    return 0;
}

int sumar(int numeroUno, int numeroDos)
{
    int suma;

    suma = numeroUno+numeroDos;

    return suma;
}
