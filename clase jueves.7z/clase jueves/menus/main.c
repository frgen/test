#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int main()
{
    char opcion;

    do
    {
        printf("(A)lta usuario\n");
        printf("(B)aja usuario\n");
        printf("(M)odificacion usuario\n");
        printf("(S)alir\n");
        printf("Elija una opcion: ");
        setbuf(stdin, NULL);
        scanf("%c", &opcion);
        opcion = toupper(opcion);

        switch(opcion)
        {
        case 'A':
            printf("Estoy dando de alta\n");
            break;
        case 'B':
            printf("Estoy dando de baja\n");
            break;
        case 'M':
            printf("Estoy modificando\n");
            break;
        case 'S':
            printf("Saliendo\n");
        default:
            printf("Opcion incorrecta\n");
        }
        system("pause");
        system("cls");

    }
    while(opcion != 'S');

    return 0;
}
